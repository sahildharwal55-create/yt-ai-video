import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadPlayfair} from '@remotion/google-fonts/PlayfairDisplay';

const poppins = loadPoppins('normal', {
  weights: ['500', '600', '700', '800'],
  subsets: ['latin'],
});
const playfair = loadPlayfair('italic', {
  weights: ['500', '600'],
  subsets: ['latin'],
});

// Bold sans for headlines + captions, elegant italic serif for emphasis words
export const FONT = poppins.fontFamily;
export const SERIF = playfair.fontFamily;
