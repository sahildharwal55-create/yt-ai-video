import {visualizeAudio} from '@remotion/media-utils';
import type {AudioData} from '@remotion/media-utils';

export const SAMPLES = 64;

export const getSpectrum = (
  audioData: AudioData | null,
  frame: number,
  fps: number,
  dataOffsetInSeconds: number,
): number[] => {
  if (!audioData) {
    return new Array(SAMPLES).fill(0);
  }
  return visualizeAudio({
    fps,
    frame,
    audioData,
    numberOfSamples: SAMPLES,
    optimizeFor: 'speed',
    dataOffsetInSeconds,
  });
};

// Speech spectra are quiet, so lift and clamp to 0..1
export const boost = (v: number): number => Math.min(1, Math.pow(Math.max(0, v), 0.7) * 1.8);

export const average = (values: number[]): number =>
  values.length === 0 ? 0 : values.reduce((a, b) => a + b, 0) / values.length;
