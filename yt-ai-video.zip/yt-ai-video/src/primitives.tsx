import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Easing,
  Interactive,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {COLORS, tint} from './theme';
import {FONT} from './fonts';

export const CLAMP = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/* ------------------------------------------------------------------ */
/* Scene timing: every scene knows its absolute start (seconds), so    */
/* elements inside can be timed with the same seconds as the audio.    */
/* ------------------------------------------------------------------ */

const SceneContext = createContext<{startSec: number; endSec: number}>({startSec: 0, endSec: 0});
export const useScene = () => useContext(SceneContext);

// Absolute time in the video (seconds), usable anywhere inside a SceneFrame
export const useAbsSec = (): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const {startSec} = useScene();
  return startSec + frame / fps;
};

const FadeWrap: React.FC<{children: React.ReactNode}> = ({children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const fadeIn = interpolate(frame, [0, 8], [0, 1], CLAMP);
  const fadeOut = interpolate(frame, [durationInFrames - 8, durationInFrames], [1, 0], CLAMP);
  return (
    <AbsoluteFill style={{opacity: fadeIn * fadeOut, scale: 0.98 + 0.02 * fadeIn}}>
      {children}
    </AbsoluteFill>
  );
};

export const SceneFrame: React.FC<{from: number; to: number; children: React.ReactNode}> = ({
  from,
  to,
  children,
}) => {
  const {fps} = useVideoConfig();
  const startFrame = Math.round(from * fps);
  const duration = Math.max(1, Math.round((to - from) * fps));
  return (
    <Sequence from={startFrame} durationInFrames={duration} layout="none">
      <SceneContext.Provider value={{startSec: from, endSec: to}}>
        <FadeWrap>{children}</FadeWrap>
      </SceneContext.Provider>
    </Sequence>
  );
};

// Content area: below the progress bar, above the captions
export const Zone: React.FC<{children: React.ReactNode; gap?: number}> = ({children, gap = 22}) => (
  <div
    style={{
      position: 'absolute',
      left: 140,
      right: 140,
      top: 150,
      height: 620,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap,
    }}
  >
    {children}
  </div>
);

/* ------------------------------------------------------------------ */
/* Animated building blocks                                            */
/* ------------------------------------------------------------------ */

export const Pop: React.FC<{
  at: number; // absolute seconds
  name?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({at, name = 'Item', style, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const {startSec} = useScene();
  const local = frame - Math.round((at - startSec) * fps);
  const p = spring({
    frame: Math.max(0, local),
    fps,
    config: {damping: 18, stiffness: 170, mass: 0.8},
  });
  const opacity = interpolate(local, [0, 5], [0, 1], CLAMP);

  return (
    <Interactive.Div
      name={name}
      style={{
        opacity,
        translate: `0px ${(1 - p) * 40}px`,
        scale: 0.9 + 0.1 * p,
        ...style,
      }}
    >
      {children}
    </Interactive.Div>
  );
};

// Red line drawn across its (position: relative) parent
export const StrikeLine: React.FC<{at: number; thickness?: number}> = ({at, thickness = 8}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const {startSec} = useScene();
  const local = frame - Math.round((at - startSec) * fps);
  const width = interpolate(local, [0, 10], [0, 100], {
    ...CLAMP,
    easing: Easing.bezier(0.16, 1, 0.3, 1),
  });
  return (
    <div
      style={{
        position: 'absolute',
        left: -6,
        top: '54%',
        height: thickness,
        width: `${width}%`,
        borderRadius: thickness,
        background: COLORS.bad,
        boxShadow: `0 0 24px ${tint(COLORS.bad, 60)}`,
      }}
    />
  );
};

// Shrinks the font so a single line fits the available width
export const fit = (text: string, max: number, width = 1640, k = 0.7): number =>
  Math.min(max, Math.floor(width / (Math.max(1, text.length) * k)));

export const kickerStyle = (color: string): React.CSSProperties => ({
  fontFamily: FONT,
  fontWeight: 700,
  fontSize: 44,
  letterSpacing: 10,
  color,
  textTransform: 'uppercase',
  textAlign: 'center',
});

/* ------------------------------------------------------------------ */
/* Icons (simple 24x24 stroke icons)                                   */
/* ------------------------------------------------------------------ */

export type IconName =
  | 'bulb'
  | 'pencil'
  | 'video'
  | 'image'
  | 'chart'
  | 'check'
  | 'x'
  | 'play'
  | 'bell'
  | 'search'
  | 'zap'
  | 'message'
  | 'mic'
  | 'smartphone'
  | 'target'
  | 'repeat'
  | 'eye'
  | 'users'
  | 'dollar'
  | 'upload'
  | 'trend'
  | 'arrow';

const PATHS: Record<IconName, React.ReactNode> = {
  bulb: (
    <>
      <path d="M9 18h6" />
      <path d="M10 22h4" />
      <path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2V17h6v-.3c0-.8.4-1.5 1-2A7 7 0 0 0 12 2z" />
    </>
  ),
  pencil: (
    <>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
    </>
  ),
  video: (
    <>
      <rect x="2" y="6" width="14" height="12" rx="2" />
      <path d="m22 8-6 4 6 4Z" />
    </>
  ),
  image: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <circle cx="9" cy="9" r="2" />
      <path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21" />
    </>
  ),
  chart: (
    <>
      <path d="M3 3v18h18" />
      <path d="m7 14 4-4 4 4 5-6" />
    </>
  ),
  check: <path d="M20 6 9 17l-5-5" />,
  x: <path d="M18 6 6 18M6 6l12 12" />,
  play: <polygon points="6 3 20 12 6 21 6 3" />,
  bell: (
    <>
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </>
  ),
  zap: <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />,
  message: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />,
  mic: (
    <>
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
      <path d="M12 19v3" />
    </>
  ),
  smartphone: (
    <>
      <rect x="5" y="2" width="14" height="20" rx="2" />
      <path d="M12 18h.01" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </>
  ),
  repeat: (
    <>
      <path d="m17 2 4 4-4 4" />
      <path d="M3 11v-1a4 4 0 0 1 4-4h14" />
      <path d="m7 22-4-4 4-4" />
      <path d="M21 13v1a4 4 0 0 1-4 4H3" />
    </>
  ),
  eye: (
    <>
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7S2 12 2 12Z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  users: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.9" />
      <path d="M16 3.1a4 4 0 0 1 0 7.8" />
    </>
  ),
  dollar: (
    <>
      <path d="M12 2v20" />
      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </>
  ),
  upload: <path d="M12 19V5M5 12l7-7 7 7" />,
  trend: (
    <>
      <path d="m22 7-8.5 8.5-5-5L2 17" />
      <path d="M16 7h6v6" />
    </>
  ),
  arrow: <path d="M5 12h14M13 5l7 7-7 7" />,
};

export const Icon: React.FC<{
  name: IconName;
  size?: number;
  color?: string;
  strokeWidth?: number;
}> = ({name, size = 64, color = '#fff', strokeWidth = 2}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={strokeWidth}
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {PATHS[name]}
  </svg>
);

export const IconBadge: React.FC<{name: IconName; color: string; size?: number}> = ({
  name,
  color,
  size = 96,
}) => (
  <div
    style={{
      width: size,
      height: size,
      flexShrink: 0,
      borderRadius: size * 0.28,
      background: tint(color, 18),
      border: `2px solid ${tint(color, 55)}`,
      display: 'grid',
      placeItems: 'center',
    }}
  >
    <Icon name={name} size={size * 0.55} color={color} strokeWidth={2} />
  </div>
);
