import {createContext, useContext} from 'react';
import {interpolateColors, useCurrentFrame, useVideoConfig} from 'remotion';

export const FPS = 30;
// Audio is 252.5s long
export const DURATION_FRAMES = 7575;

export const COLORS = {
  bg: '#060812',
  muted: '#9AA4BC',
  bad: '#FF5C5C',
  green: '#34D399',
  card: 'rgba(255,255,255,0.06)',
};

export type Chapter = {
  id: string;
  label: string;
  from: number; // seconds
  to: number; // seconds
  color: string;
  step?: number;
};

// Chapter boundaries line up with scene boundaries in Scenes.tsx
export const CHAPTERS: Chapter[] = [
  {id: 'intro', label: 'INTRO', from: 0, to: 39.6, color: '#FF4D4D'},
  {id: 's1', label: 'IDEAS', from: 39.6, to: 76.4, color: '#FBBF24', step: 1},
  {id: 's2', label: 'SCRIPTS', from: 76.4, to: 111.9, color: '#A78BFA', step: 2},
  {id: 's3', label: 'CREATE', from: 111.9, to: 148.0, color: '#22D3EE', step: 3},
  {id: 's4', label: 'TITLES', from: 148.0, to: 185.7, color: '#F472B6', step: 4},
  {id: 's5', label: 'ANALYTICS', from: 185.7, to: 220.2, color: '#34D399', step: 5},
  {id: 'outro', label: 'WRAP-UP', from: 220.2, to: 252.5, color: '#FF4D4D'},
];

export const AccentContext = createContext<string>('#FF4D4D');
export const useAccent = (): string => useContext(AccentContext);

// Must be called from the root composition (global frame), not inside a <Sequence>
export const useChapterAccent = (): string => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const input: number[] = [];
  const output: string[] = [];
  CHAPTERS.forEach((c, i) => {
    input.push(i === 0 ? 0 : Math.round(c.from * fps) + 15);
    output.push(c.color);
    input.push(Math.round(c.to * fps));
    output.push(c.color);
  });
  return interpolateColors(frame, input, output);
};

export const tint = (color: string, pct: number): string =>
  `color-mix(in srgb, ${color} ${pct}%, transparent)`;
