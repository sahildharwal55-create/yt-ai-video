import React from 'react';
import {Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {createSmoothSvgPath} from '@remotion/media-utils';
import {COLORS, tint, useAccent} from './theme';
import {FONT, SERIF} from './fonts';
import {
  CLAMP,
  Icon,
  IconBadge,
  Pop,
  SceneFrame,
  StrikeLine,
  Zone,
  fit,
  kickerStyle,
  useAbsSec,
  useScene,
} from './primitives';
import type {IconName} from './primitives';

/* ================================================================== */
/* Scene data types                                                    */
/* ================================================================== */

type Tone = 'accent' | 'bad' | 'good' | 'strike' | 'muted' | 'plain';
type Line = {text: string; at: number; size?: number; tone?: Tone};
type Timed = {text: string; at: number};
type Item = {
  at: number;
  text: string;
  sub?: string;
  icon?: IconName;
  tone?: 'default' | 'strike' | 'good' | 'bad';
};
type Side = {title: string; text: string; at: number; tone: 'good' | 'bad' | 'accent'};

type SceneDef =
  | {kind: 'hero'; from: number; to: number; icon?: IconName; kicker?: Timed; lines: Line[]}
  | {kind: 'stepIntro'; from: number; to: number; n: number; title: string; icon: IconName}
  | {kind: 'stack'; from: number; to: number; title?: Timed; items: Item[]; cols?: 1 | 2 | 3}
  | {kind: 'versus'; from: number; to: number; title?: Timed; left: Side; right: Side}
  | {
      kind: 'prompt';
      from: number;
      to: number;
      label: Timed;
      text: string;
      typeFrom: number;
      typeTo: number;
    }
  | {
      kind: 'chart';
      from: number;
      to: number;
      variant: 'rising' | 'dropping' | 'flat';
      title: Timed;
      notes: {text: string; at: number; tone: Tone}[];
      drawAt: number;
    }
  | {
      kind: 'cycle';
      from: number;
      to: number;
      title: Timed;
      items: {text: string; at: number; icon: IconName}[];
    }
  | {
      kind: 'equation';
      from: number;
      to: number;
      kicker: Timed;
      left: Timed;
      plusAt: number;
      right: Timed;
    }
  | {
      kind: 'bigNumber';
      from: number;
      to: number;
      n: string;
      nAt: number;
      label: Timed;
      sub: Timed;
      foot: Timed;
    }
  | {kind: 'cta'; from: number; to: number};

const toneColor = (tone: Tone | undefined, accent: string): string => {
  switch (tone) {
    case 'bad':
      return COLORS.bad;
    case 'good':
      return COLORS.green;
    case 'accent':
      return accent;
    case 'muted':
      return COLORS.muted;
    default:
      return '#FFFFFF';
  }
};

/* ================================================================== */
/* Scene components                                                    */
/* ================================================================== */

const HeroLine: React.FC<{line: Line; index: number}> = ({line, index}) => {
  const accent = useAccent();
  const tone = line.tone ?? 'plain';
  const isAccent = tone === 'accent';
  const size = fit(line.text, line.size ?? 120, 1640, isAccent ? 0.5 : 0.7);
  return (
    <Pop at={line.at} name={`Line ${index + 1}`}>
      <div
        style={{
          position: 'relative',
          display: 'inline-block',
          fontFamily: isAccent ? SERIF : FONT,
          fontStyle: isAccent ? 'italic' : 'normal',
          fontWeight: isAccent ? 500 : 800,
          fontSize: size,
          lineHeight: 1.06,
          letterSpacing: isAccent ? 0 : -2,
          color: toneColor(tone, accent),
          textShadow: isAccent ? `0 0 70px ${tint(accent, 45)}` : undefined,
          textAlign: 'center',
          whiteSpace: 'nowrap',
          opacity: tone === 'strike' ? 0.85 : 1,
        }}
      >
        {line.text}
        {tone === 'strike' && <StrikeLine at={line.at + 0.8} thickness={10} />}
      </div>
    </Pop>
  );
};

const HeroScene: React.FC<{def: Extract<SceneDef, {kind: 'hero'}>}> = ({def}) => {
  const accent = useAccent();
  const firstAt = Math.min(def.kicker ? def.kicker.at : Infinity, def.lines[0].at);
  return (
    <Zone gap={18}>
      {def.icon && (
        <Pop at={firstAt} name="Icon">
          <IconBadge name={def.icon} color={accent} size={120} />
        </Pop>
      )}
      {def.kicker && (
        <Pop at={def.kicker.at} name="Kicker">
          <div style={kickerStyle(accent)}>{def.kicker.text}</div>
        </Pop>
      )}
      {def.lines.map((line, i) => (
        <HeroLine key={i} line={line} index={i} />
      ))}
    </Zone>
  );
};

const StepIntroScene: React.FC<{def: Extract<SceneDef, {kind: 'stepIntro'}>}> = ({def}) => {
  const accent = useAccent();
  const {startSec} = useScene();
  const titleSize = def.title.length <= 18 ? 110 : def.title.length <= 26 ? 96 : 82;
  return (
    <>
      <Pop
        at={startSec}
        name="Big number"
        style={{
          position: 'absolute',
          right: 110,
          top: 70,
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 560,
          lineHeight: 1,
          color: 'transparent',
          WebkitTextStroke: `3px ${tint(accent, 35)}`,
        }}
      >
        {`0${def.n}`}
      </Pop>
      <Zone gap={0}>
        <div style={{display: 'flex', alignItems: 'center', gap: 70}}>
          <Pop at={startSec + 0.05} name="Icon">
            <div
              style={{
                width: 330,
                height: 330,
                borderRadius: 80,
                background: tint(accent, 16),
                border: `4px solid ${accent}`,
                display: 'grid',
                placeItems: 'center',
                boxShadow: `0 0 120px ${tint(accent, 45)}`,
              }}
            >
              <Icon name={def.icon} size={170} color={accent} strokeWidth={1.6} />
            </div>
          </Pop>
          <div style={{display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 1050}}>
            <Pop at={startSec + 0.15} name="Step label">
              <div style={{...kickerStyle(accent), textAlign: 'left', fontSize: 40}}>
                {`STEP 0${def.n} / 05`}
              </div>
            </Pop>
            <Pop at={startSec + 0.3} name="Step title">
              <div
                style={{
                  fontFamily: FONT,
                  fontWeight: 800,
                  fontSize: titleSize,
                  lineHeight: 1.03,
                  letterSpacing: -2,
                  color: '#fff',
                }}
              >
                {def.title}
              </div>
            </Pop>
          </div>
        </div>
      </Zone>
    </>
  );
};

const ItemCard: React.FC<{item: Item; cols: 1 | 2 | 3}> = ({item, cols}) => {
  const accent = useAccent();
  const tone = item.tone ?? 'default';
  const color = tone === 'good' ? COLORS.green : tone === 'bad' || tone === 'strike' ? COLORS.bad : accent;
  const icon: IconName = tone === 'good' ? (item.icon ?? 'check') : (item.icon ?? 'zap');
  const fontSize = cols === 1 ? 52 : cols === 2 ? 44 : 38;
  const vertical = cols === 3;
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: vertical ? 'column' : 'row',
        alignItems: 'center',
        gap: vertical ? 18 : 26,
        padding: vertical ? '28px 24px' : '28px 38px',
        minHeight: vertical ? 220 : 130,
        borderRadius: 30,
        background: COLORS.card,
        border: `2px solid ${tint(color, 45)}`,
        boxShadow: '0 18px 50px rgba(0,0,0,0.35)',
        textAlign: vertical ? 'center' : 'left',
        justifyContent: vertical ? 'center' : 'flex-start',
      }}
    >
      <IconBadge name={icon} color={color} size={vertical ? 84 : 92} />
      <div
        style={{
          fontFamily: FONT,
          fontWeight: 700,
          fontSize,
          lineHeight: 1.15,
          color: '#fff',
          opacity: tone === 'strike' ? 0.85 : 1,
        }}
      >
        <span style={{position: 'relative', display: 'inline-block'}}>
          {item.text}
          {tone === 'strike' && <StrikeLine at={item.at + 0.7} />}
        </span>
        {item.sub && (
          <div style={{fontSize: fontSize * 0.62, fontWeight: 500, color: COLORS.muted, marginTop: 6}}>
            {item.sub}
          </div>
        )}
      </div>
    </div>
  );
};

const StackScene: React.FC<{def: Extract<SceneDef, {kind: 'stack'}>}> = ({def}) => {
  const cols = def.cols ?? 1;
  return (
    <Zone gap={30}>
      {def.title && (
        <Pop at={def.title.at} name="Title">
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: fit(def.title.text, 84),
              letterSpacing: -1,
              color: '#fff',
              textAlign: 'center',
              whiteSpace: 'nowrap',
            }}
          >
            {def.title.text}
          </div>
        </Pop>
      )}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${cols}, 1fr)`,
          gap: 24,
          width: cols === 1 ? 1250 : 1640,
        }}
      >
        {def.items.map((item, i) => (
          <Pop key={i} at={item.at} name={`Card ${i + 1}`}>
            <ItemCard item={item} cols={cols} />
          </Pop>
        ))}
      </div>
    </Zone>
  );
};

const VersusScene: React.FC<{def: Extract<SceneDef, {kind: 'versus'}>}> = ({def}) => {
  const accent = useAccent();
  const sideColor = (s: Side) => (s.tone === 'good' ? COLORS.green : s.tone === 'bad' ? COLORS.bad : accent);
  return (
    <Zone gap={34}>
      {def.title && (
        <Pop at={def.title.at} name="Title">
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: fit(def.title.text, 76),
              letterSpacing: -1,
              color: '#fff',
              textAlign: 'center',
              whiteSpace: 'nowrap',
            }}
          >
            {def.title.text}
          </div>
        </Pop>
      )}
      <div style={{display: 'flex', gap: 36, width: 1640}}>
        {[def.left, def.right].map((side, i) => {
          const color = sideColor(side);
          const textSize = side.text.length <= 24 ? 66 : side.text.length <= 50 ? 54 : 46;
          return (
            <Pop key={i} at={side.at} name={i === 0 ? 'Left' : 'Right'} style={{flex: 1}}>
              <div
                style={{
                  background: tint(color, 10),
                  border: `3px solid ${tint(color, 70)}`,
                  borderRadius: 36,
                  padding: '34px 44px',
                  minHeight: 360,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 26,
                  boxShadow: `0 0 90px ${tint(color, 14)}`,
                }}
              >
                <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
                  <IconBadge name={side.tone === 'bad' ? 'x' : 'check'} color={color} size={78} />
                  <span
                    style={{
                      fontFamily: FONT,
                      fontWeight: 800,
                      fontSize: 40,
                      letterSpacing: 4,
                      color,
                    }}
                  >
                    {side.title}
                  </span>
                </div>
                <div
                  style={{
                    fontFamily: FONT,
                    fontWeight: 700,
                    fontSize: textSize,
                    lineHeight: 1.15,
                    color: '#fff',
                  }}
                >
                  {side.text}
                </div>
              </div>
            </Pop>
          );
        })}
      </div>
    </Zone>
  );
};

const PromptScene: React.FC<{def: Extract<SceneDef, {kind: 'prompt'}>}> = ({def}) => {
  const accent = useAccent();
  const frame = useCurrentFrame();
  const cur = useAbsSec();
  const typed = Math.floor(interpolate(cur, [def.typeFrom, def.typeTo], [0, def.text.length], CLAMP));
  const caretOn = Math.floor(frame / 15) % 2 === 0;
  return (
    <Zone gap={34}>
      <Pop at={def.label.at} name="Label">
        <div style={kickerStyle(accent)}>{def.label.text}</div>
      </Pop>
      <Pop at={def.typeFrom - 0.5} name="Prompt window">
        <div
          style={{
            width: 1560,
            borderRadius: 36,
            background: 'rgba(14,18,34,0.92)',
            border: '2px solid rgba(255,255,255,0.14)',
            boxShadow: `0 30px 90px rgba(0,0,0,0.5), 0 0 120px ${tint(accent, 16)}`,
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '20px 30px',
              background: 'rgba(255,255,255,0.05)',
            }}
          >
            {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => (
              <div key={c} style={{width: 18, height: 18, borderRadius: 9, background: c}} />
            ))}
            <span
              style={{
                marginLeft: 16,
                fontFamily: FONT,
                fontWeight: 600,
                fontSize: 28,
                letterSpacing: 2,
                color: COLORS.muted,
              }}
            >
              ChatGPT
            </span>
          </div>
          <div
            style={{
              padding: '36px 48px 44px',
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 50,
              lineHeight: 1.35,
              color: '#fff',
              minHeight: 300,
            }}
          >
            <span>{def.text.slice(0, typed)}</span>
            <span
              style={{
                display: 'inline-block',
                width: 4,
                height: 52,
                marginLeft: 4,
                verticalAlign: 'middle',
                background: accent,
                opacity: caretOn ? 1 : 0,
              }}
            />
            <span style={{opacity: 0}}>{def.text.slice(typed)}</span>
          </div>
        </div>
      </Pop>
    </Zone>
  );
};

const CHART_POINTS: Record<'rising' | 'dropping' | 'flat', [number, number][]> = {
  rising: [
    [0, 400], [140, 370], [280, 385], [420, 300], [560, 320], [700, 230],
    [840, 240], [980, 150], [1120, 120], [1260, 70], [1400, 30],
  ],
  dropping: [
    [0, 40], [90, 48], [190, 150], [300, 260], [420, 330], [560, 380],
    [760, 410], [1000, 420], [1400, 428],
  ],
  flat: [
    [0, 420], [200, 414], [400, 424], [600, 416], [800, 422],
    [1000, 415], [1200, 421], [1400, 418],
  ],
};

const ChartScene: React.FC<{def: Extract<SceneDef, {kind: 'chart'}>}> = ({def}) => {
  const accent = useAccent();
  const cur = useAbsSec();
  const color = def.variant === 'dropping' ? COLORS.bad : def.variant === 'rising' ? COLORS.green : accent;
  const progress = interpolate(cur, [def.drawAt, def.drawAt + 2.4], [0, 1], {
    ...CLAMP,
    easing: Easing.out(Easing.cubic),
  });
  const path = createSmoothSvgPath({
    points: CHART_POINTS[def.variant].map(([x, y]) => ({x, y})),
  });
  const width = def.notes.length > 1 ? 920 : 1080;
  const clipId = `clip-${def.variant}`;
  return (
    <Zone gap={22}>
      <Pop at={def.title.at} name="Title">
        <div
          style={{
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: fit(def.title.text, 80),
            letterSpacing: -1,
            color: '#fff',
            textAlign: 'center',
            whiteSpace: 'nowrap',
          }}
        >
          {def.title.text}
        </div>
      </Pop>
      <Pop at={def.drawAt - 0.3} name="Chart">
        <svg width={width} height={(width * 460) / 1400} viewBox="0 0 1400 460">
          <defs>
            <clipPath id={clipId}>
              <rect x="0" y="0" width={progress * 1400} height="460" />
            </clipPath>
            <linearGradient id={`fill-${def.variant}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.35" />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0, 1, 2, 3].map((i) => (
            <line
              key={i}
              x1="0"
              x2="1400"
              y1={20 + i * 140}
              y2={20 + i * 140}
              stroke="rgba(255,255,255,0.10)"
              strokeWidth="2"
            />
          ))}
          <g clipPath={`url(#${clipId})`}>
            <path d={`${path} L 1400 440 L 0 440 Z`} fill={`url(#fill-${def.variant})`} />
            <path
              d={path}
              fill="none"
              stroke={color}
              strokeWidth="12"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </g>
        </svg>
      </Pop>
      {def.notes.map((note, i) => (
        <Pop key={i} at={note.at} name={`Note ${i + 1}`}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 700,
              fontSize: fit(note.text, 46, 1500, 0.66),
              letterSpacing: 1,
              padding: '10px 36px',
              borderRadius: 999,
              color: toneColor(note.tone, accent),
              background: tint(toneColor(note.tone, accent), 14),
              border: `2px solid ${tint(toneColor(note.tone, accent), 50)}`,
              whiteSpace: 'nowrap',
            }}
          >
            {note.text}
          </div>
        </Pop>
      ))}
    </Zone>
  );
};

const CycleScene: React.FC<{def: Extract<SceneDef, {kind: 'cycle'}>}> = ({def}) => {
  const accent = useAccent();
  const cur = useAbsSec();
  const last = def.items[def.items.length - 1].at;
  const pulse = cur >= last ? 1 + 0.04 * Math.sin((cur - last) * 7) : 1;
  return (
    <Zone gap={50}>
      <Pop at={def.title.at} name="Title">
        <div
          style={{
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: fit(def.title.text, 84),
            letterSpacing: -1,
            color: '#fff',
            textAlign: 'center',
            whiteSpace: 'nowrap',
          }}
        >
          {def.title.text}
        </div>
      </Pop>
      <div style={{display: 'flex', alignItems: 'center', gap: 36, scale: pulse}}>
        {def.items.map((item, i) => (
          <React.Fragment key={i}>
            {i > 0 && (
              <Pop at={item.at - 0.1} name={`Arrow ${i}`}>
                <Icon name="arrow" size={72} color={COLORS.muted} strokeWidth={2.4} />
              </Pop>
            )}
            <Pop at={item.at} name={`Node ${i + 1}`}>
              <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
                <div
                  style={{
                    width: 190,
                    height: 190,
                    borderRadius: 95,
                    background: tint(accent, 16),
                    border: `4px solid ${accent}`,
                    display: 'grid',
                    placeItems: 'center',
                    boxShadow: `0 0 70px ${tint(accent, 35)}`,
                  }}
                >
                  <Icon name={item.icon} size={92} color={accent} strokeWidth={1.8} />
                </div>
                <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 48, color: '#fff'}}>
                  {item.text}
                </div>
              </div>
            </Pop>
          </React.Fragment>
        ))}
      </div>
    </Zone>
  );
};

const EquationScene: React.FC<{def: Extract<SceneDef, {kind: 'equation'}>}> = ({def}) => {
  const accent = useAccent();
  const box = (accented: boolean): React.CSSProperties => ({
    padding: '34px 62px',
    borderRadius: 40,
    background: accented ? tint(accent, 18) : COLORS.card,
    border: `3px solid ${accented ? accent : 'rgba(255,255,255,0.18)'}`,
    fontFamily: FONT,
    fontWeight: 800,
    fontSize: 104,
    letterSpacing: -2,
    color: accented ? accent : '#fff',
    boxShadow: accented ? `0 0 110px ${tint(accent, 30)}` : undefined,
    whiteSpace: 'nowrap',
  });
  return (
    <Zone gap={44}>
      <Pop at={def.kicker.at} name="Kicker">
        <div style={kickerStyle(accent)}>{def.kicker.text}</div>
      </Pop>
      <div style={{display: 'flex', alignItems: 'center', gap: 50}}>
        <Pop at={def.left.at} name="Left">
          <div style={box(false)}>{def.left.text}</div>
        </Pop>
        <Pop at={def.plusAt} name="Plus">
          <span style={{fontFamily: FONT, fontWeight: 800, fontSize: 120, color: COLORS.muted}}>+</span>
        </Pop>
        <Pop at={def.right.at} name="Right">
          <div style={box(true)}>{def.right.text}</div>
        </Pop>
      </div>
    </Zone>
  );
};

const BigNumberScene: React.FC<{def: Extract<SceneDef, {kind: 'bigNumber'}>}> = ({def}) => {
  const accent = useAccent();
  return (
    <Zone>
      <div style={{display: 'flex', alignItems: 'center', gap: 90}}>
        <Pop at={def.nAt} name="Number">
          <div
            style={{
              fontFamily: SERIF,
              fontStyle: 'italic',
              fontWeight: 600,
              fontSize: 520,
              lineHeight: 0.9,
              color: accent,
              textShadow: `0 0 120px ${tint(accent, 50)}`,
            }}
          >
            {def.n}
          </div>
        </Pop>
        <div style={{display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 1000}}>
          <Pop at={def.label.at} name="Label">
            <div
              style={{
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: 84,
                lineHeight: 1.05,
                letterSpacing: -1,
                color: '#fff',
              }}
            >
              {def.label.text}
            </div>
          </Pop>
          <Pop at={def.sub.at} name="Sub">
            <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 46, letterSpacing: 2, color: accent}}>
              {def.sub.text}
            </div>
          </Pop>
          <Pop at={def.foot.at} name="Foot">
            <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 38, color: COLORS.muted}}>
              {def.foot.text}
            </div>
          </Pop>
        </div>
      </div>
    </Zone>
  );
};

const CtaScene: React.FC = () => {
  const accent = useAccent();
  const cur = useAbsSec();
  const CLICK_AT = 244.0;
  const clicked = cur >= CLICK_AT;
  const wiggle = clicked
    ? Math.sin((cur - CLICK_AT) * 20) * interpolate(cur, [CLICK_AT, CLICK_AT + 1.2], [1, 0], CLAMP) * 24
    : 0;
  const ring = interpolate(cur, [CLICK_AT, CLICK_AT + 0.6], [0, 1], CLAMP);
  return (
    <Zone gap={44}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Pop at={243.0} name="Subscribe button">
          <div style={{position: 'relative'}}>
            <div
              style={{
                padding: '28px 80px',
                borderRadius: 999,
                background: clicked ? '#3A3F52' : '#FF2D2D',
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: 64,
                letterSpacing: 2,
                color: '#fff',
                boxShadow: clicked ? 'none' : '0 0 90px rgba(255,45,45,0.45)',
              }}
            >
              {clicked ? 'SUBSCRIBED' : 'SUBSCRIBE'}
            </div>
            {clicked && (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  borderRadius: 999,
                  border: '6px solid #FF2D2D',
                  opacity: 1 - ring,
                  scale: 1 + ring * 0.35,
                }}
              />
            )}
          </div>
        </Pop>
        <Pop at={243.4} name="Bell">
          <div
            style={{
              width: 130,
              height: 130,
              borderRadius: 65,
              background: COLORS.card,
              border: '2px solid rgba(255,255,255,0.2)',
              display: 'grid',
              placeItems: 'center',
              rotate: `${wiggle}deg`,
            }}
          >
            <Icon name="bell" size={68} color={clicked ? accent : '#fff'} strokeWidth={2} />
          </div>
        </Pop>
      </div>
      <Pop at={244.4} name="Comment kicker">
        <div style={kickerStyle(accent)}>COMMENT BELOW</div>
      </Pop>
      <Pop at={245.8} name="Question">
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 28,
            padding: '30px 54px',
            borderRadius: 36,
            background: COLORS.card,
            border: `2px solid ${tint(accent, 50)}`,
            boxShadow: `0 0 100px ${tint(accent, 18)}`,
          }}
        >
          <IconBadge name="message" color={accent} size={96} />
          <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 56, letterSpacing: -1, color: '#fff'}}>
            Which AI tool will you use first?
          </div>
        </div>
      </Pop>
    </Zone>
  );
};

/* ================================================================== */
/* Timeline: every scene, in seconds of the audio                      */
/* ================================================================== */

export const SCENE_DEFS: SceneDef[] = [
  /* ---------- INTRO ---------- */
  {
    kind: 'hero', from: 0, to: 5.0,
    lines: [
      {text: 'HOW TO GROW YOUR', at: 0.4, size: 104},
      {text: 'YouTube channel', at: 1.2, size: 170, tone: 'accent'},
      {text: 'IN 2026 USING AI', at: 2.6, size: 104},
    ],
  },
  {
    kind: 'stack', from: 5.0, to: 14.6,
    title: {text: "YOU DON'T NEED", at: 5.0},
    items: [
      {at: 6.8, text: 'An expensive camera', icon: 'video', tone: 'strike'},
      {at: 9.2, text: 'A professional team', icon: 'users', tone: 'strike'},
      {at: 10.8, text: 'Thousands of dollars', icon: 'dollar', tone: 'strike'},
    ],
  },
  {
    kind: 'equation', from: 14.6, to: 19.0,
    kicker: {text: 'YOU JUST NEED', at: 14.6},
    left: {text: 'THE RIGHT STRATEGY', at: 16.0},
    plusAt: 16.6,
    right: {text: 'AI', at: 17.8},
  },
  {
    kind: 'hero', from: 19.0, to: 23.6,
    lines: [
      {text: "BUT HERE'S THE TRUTH:", at: 19.2, size: 60, tone: 'muted'},
      {text: 'THOUSANDS OF CREATORS', at: 20.6, size: 118},
      {text: 'are using AI', at: 21.6, size: 150, tone: 'accent'},
    ],
  },
  {
    kind: 'chart', from: 23.6, to: 26.8, variant: 'flat', drawAt: 24.0,
    title: {text: 'YET MOST STILL STRUGGLE', at: 23.6},
    notes: [{text: 'TO GET VIEWS', at: 25.0, tone: 'bad'}],
  },
  {
    kind: 'hero', from: 26.8, to: 29.0,
    lines: [{text: 'Why?', at: 26.8, size: 300, tone: 'accent'}],
  },
  {
    kind: 'hero', from: 29.0, to: 30.8, icon: 'x',
    lines: [
      {text: 'USING AI', at: 29.2, size: 120},
      {text: 'THE WRONG WAY', at: 29.8, size: 130, tone: 'bad'},
    ],
  },
  {
    kind: 'bigNumber', from: 30.8, to: 39.6, n: '5', nAt: 32.4,
    label: {text: 'PRACTICAL WAYS TO USE AI', at: 32.8},
    sub: {text: 'TO GROW YOUR YOUTUBE CHANNEL', at: 34.8},
    foot: {text: "EVEN IF YOU'RE A COMPLETE BEGINNER", at: 38.0},
  },

  /* ---------- STEP 1: IDEAS ---------- */
  {kind: 'stepIntro', from: 39.6, to: 43.0, n: 1, title: 'FIND BETTER VIDEO IDEAS', icon: 'bulb'},
  {
    kind: 'stack', from: 43.0, to: 51.8,
    title: {text: 'STOP GUESSING', at: 43.2},
    items: [
      {at: 45.0, text: 'What your audience wants to watch', icon: 'eye'},
      {at: 46.6, text: 'Brainstorm video ideas with ChatGPT', icon: 'message'},
      {at: 50.0, text: 'Based on your niche', icon: 'target'},
    ],
  },
  {
    kind: 'prompt', from: 51.8, to: 61.2,
    label: {text: 'FOR EXAMPLE, ASK:', at: 51.8},
    text: 'Give me 10 engaging YouTube video ideas for an educational channel targeting beginners in 2026.',
    typeFrom: 53.8, typeTo: 60.4,
  },
  {
    kind: 'stack', from: 61.2, to: 70.5, cols: 2,
    items: [
      {at: 61.2, text: 'Search those topics on YouTube', icon: 'search'},
      {at: 64.6, text: 'Study popular videos', icon: 'eye'},
      {at: 66.6, text: 'Identify unanswered questions', icon: 'message'},
      {at: 68.6, text: 'Create something more useful', icon: 'bulb'},
    ],
  },
  {
    kind: 'versus', from: 70.5, to: 76.4,
    title: {text: 'REMEMBER', at: 70.6},
    left: {title: "DON'T JUST", text: "Copy what's trending", at: 72.2, tone: 'bad'},
    right: {title: 'INSTEAD', text: 'Find a problem your audience wants to solve', at: 73.2, tone: 'good'},
  },

  /* ---------- STEP 2: SCRIPTS ---------- */
  {kind: 'stepIntro', from: 76.4, to: 80.4, n: 2, title: 'WRITE ENGAGING SCRIPTS WITH AI', icon: 'pencil'},
  {
    kind: 'hero', from: 80.4, to: 84.1, icon: 'eye',
    kicker: {text: 'YOUR NEXT CHALLENGE', at: 80.6},
    lines: [
      {text: 'KEEPING VIEWERS', at: 82.0, size: 118},
      {text: 'interested', at: 83.2, size: 160, tone: 'accent'},
    ],
  },
  {
    kind: 'chart', from: 84.1, to: 89.0, variant: 'dropping', drawAt: 85.0,
    title: {text: 'A WEAK INTRODUCTION', at: 84.2},
    notes: [{text: 'VIEWERS LEAVE BEFORE YOUR VIDEO BEGINS', at: 86.8, tone: 'bad'}],
  },
  {
    kind: 'stack', from: 89.0, to: 96.7, cols: 2,
    title: {text: 'USE AI TO CREATE', at: 89.0},
    items: [
      {at: 90.6, text: 'A powerful hook', icon: 'zap'},
      {at: 92.4, text: 'A clear structure', icon: 'target'},
      {at: 93.6, text: 'Simple explanations', icon: 'message'},
      {at: 94.8, text: 'Interesting examples', icon: 'bulb'},
    ],
  },
  {
    kind: 'stack', from: 96.7, to: 105.0,
    title: {text: "DON'T PUBLISH THE FIRST SCRIPT", at: 96.8},
    items: [
      {at: 100.0, text: 'Add your own opinions', icon: 'check', tone: 'good'},
      {at: 101.8, text: 'Verify the facts', icon: 'check', tone: 'good'},
      {at: 103.0, text: 'Make it sound natural', icon: 'check', tone: 'good'},
    ],
  },
  {
    kind: 'versus', from: 105.0, to: 111.9,
    left: {title: 'AI', text: 'Helps you write faster', at: 105.2, tone: 'good'},
    right: {title: 'YOU', text: 'Your unique perspective makes your content different', at: 107.6, tone: 'accent'},
  },

  /* ---------- STEP 3: CREATE ---------- */
  {kind: 'stepIntro', from: 111.9, to: 115.0, n: 3, title: 'CREATE VIDEOS FASTER', icon: 'video'},
  {
    kind: 'stack', from: 115.0, to: 127.0, cols: 3,
    items: [
      {at: 115.0, text: 'No expensive equipment', icon: 'video'},
      {at: 117.8, text: 'Record your voice', icon: 'mic'},
      {at: 119.2, text: 'Use your phone', icon: 'smartphone'},
      {at: 121.4, text: 'Add relevant visuals', icon: 'image'},
      {at: 122.4, text: 'Create subtitles', icon: 'message'},
      {at: 125.0, text: 'Edit with mobile tools', icon: 'pencil'},
    ],
  },
  {
    kind: 'stack', from: 127.0, to: 133.0, cols: 3,
    title: {text: 'AI CAN HELP YOU', at: 127.0},
    items: [
      {at: 128.4, text: 'Generate visual ideas', icon: 'bulb'},
      {at: 130.0, text: 'Organize scenes', icon: 'video'},
      {at: 131.4, text: 'Improve your workflow', icon: 'repeat'},
    ],
  },
  {
    kind: 'stack', from: 133.0, to: 141.8, cols: 3,
    title: {text: "DON'T WANT TO SHOW YOUR FACE?", at: 133.0},
    items: [
      {at: 136.8, text: 'Screen recordings', icon: 'video'},
      {at: 139.2, text: 'Animations', icon: 'zap'},
      {at: 140.0, text: 'Voiceovers', icon: 'mic'},
    ],
  },
  {
    kind: 'hero', from: 141.8, to: 148.0,
    lines: [
      {text: "THE GOAL ISN'T", at: 141.8, size: 64, tone: 'muted'},
      {text: 'MORE VIDEOS', at: 143.2, size: 130, tone: 'strike'},
      {text: 'USEFUL VIDEOS', at: 145.2, size: 130},
      {text: 'more efficiently', at: 146.8, size: 140, tone: 'accent'},
    ],
  },

  /* ---------- STEP 4: TITLES & THUMBNAILS ---------- */
  {kind: 'stepIntro', from: 148.0, to: 152.0, n: 4, title: 'IMPROVE TITLES & THUMBNAILS', icon: 'image'},
  {
    kind: 'hero', from: 152.0, to: 156.0, icon: 'video',
    lines: [
      {text: 'AN AMAZING VIDEO', at: 153.0, size: 120},
      {text: 'NOBODY CLICKS ON IT', at: 155.4, size: 120, tone: 'bad'},
    ],
  },
  {
    kind: 'hero', from: 156.0, to: 159.5, icon: 'image',
    lines: [
      {text: 'YOUR TITLE', at: 156.2, size: 130},
      {text: '& thumbnail matter', at: 157.4, size: 150, tone: 'accent'},
    ],
  },
  {
    kind: 'stack', from: 159.5, to: 163.5,
    title: {text: 'ASK AI TO SUGGEST', at: 159.6},
    items: [
      {at: 161.2, text: 'Five curiosity-driven titles', icon: 'zap'},
      {at: 162.6, text: 'For your topic', icon: 'target'},
    ],
  },
  {
    kind: 'stack', from: 163.5, to: 170.0, cols: 3,
    title: {text: 'KEEP YOUR THUMBNAIL', at: 163.6},
    items: [
      {at: 165.4, text: 'Simple', icon: 'image'},
      {at: 166.4, text: 'Readable text', icon: 'eye'},
      {at: 168.0, text: 'One clear idea', icon: 'bulb'},
    ],
  },
  {
    kind: 'versus', from: 170.0, to: 178.5,
    title: {text: 'FOR EXAMPLE', at: 170.0},
    left: {title: 'INSTEAD OF', text: 'A generic title', at: 171.4, tone: 'bad'},
    right: {title: 'TRY', text: '\u201CGrow your YouTube channel faster using AI in 2026.\u201D', at: 173.2, tone: 'good'},
  },
  {
    kind: 'hero', from: 178.5, to: 185.7,
    lines: [
      {text: 'NEVER MAKE', at: 178.6, size: 70, tone: 'muted'},
      {text: 'FALSE PROMISES', at: 179.2, size: 140, tone: 'bad'},
      {text: 'Your video must deliver', at: 181.6, size: 80},
      {text: 'what your title promises', at: 182.8, size: 120, tone: 'accent'},
    ],
  },

  /* ---------- STEP 5: ANALYTICS ---------- */
  {kind: 'stepIntro', from: 185.7, to: 188.2, n: 5, title: 'LEARN FROM YOUR ANALYTICS', icon: 'chart'},
  {
    kind: 'versus', from: 188.2, to: 194.0,
    title: {text: 'THE STEP THAT SEPARATES CREATORS', at: 188.2},
    left: {title: 'CREATORS WHO', text: 'IMPROVE', at: 190.0, tone: 'good'},
    right: {title: 'CREATORS WHO', text: 'KEEP GUESSING', at: 192.6, tone: 'bad'},
  },
  {
    kind: 'hero', from: 194.0, to: 197.3, icon: 'chart',
    kicker: {text: 'OPEN', at: 194.0},
    lines: [
      {text: 'YouTube Studio', at: 194.4, size: 150, tone: 'accent'},
      {text: 'STUDY YOUR ANALYTICS', at: 196.0, size: 100},
    ],
  },
  {
    kind: 'stack', from: 197.3, to: 203.2,
    items: [
      {at: 197.4, text: 'Are people clicking your videos?', icon: 'eye'},
      {at: 199.6, text: 'How long are they watching?', icon: 'video'},
      {at: 201.0, text: 'At what point are they leaving?', icon: 'chart'},
    ],
  },
  {
    kind: 'chart', from: 203.2, to: 210.0, variant: 'rising', drawAt: 204.4,
    title: {text: 'USE THESE INSIGHTS', at: 203.2},
    notes: [
      {text: 'TO IMPROVE YOUR NEXT VIDEO', at: 204.6, tone: 'good'},
      {text: 'LEAVING EARLY? IMPROVE YOUR INTRODUCTION', at: 206.8, tone: 'accent'},
    ],
  },
  {
    kind: 'hero', from: 210.0, to: 214.3,
    lines: [
      {text: 'IF A TOPIC ATTRACTS THE RIGHT AUDIENCE', at: 210.0, size: 78},
      {text: 'explore related topics', at: 212.4, size: 150, tone: 'accent'},
    ],
  },
  {
    kind: 'cycle', from: 214.3, to: 220.2,
    title: {text: "DON'T JUST UPLOAD AND HOPE", at: 214.4},
    items: [
      {text: 'Upload', at: 216.6, icon: 'upload'},
      {text: 'Analyze', at: 217.5, icon: 'chart'},
      {text: 'Learn', at: 218.4, icon: 'bulb'},
      {text: 'Improve', at: 219.2, icon: 'trend'},
    ],
  },

  /* ---------- WRAP-UP ---------- */
  {
    kind: 'hero', from: 220.2, to: 222.5,
    lines: [
      {text: 'POWERFUL ENDING', at: 220.2, size: 120},
      {text: '+ CTA', at: 221.2, size: 170, tone: 'accent'},
    ],
  },
  {
    kind: 'versus', from: 222.5, to: 234.0,
    left: {title: 'AI IS NOT', text: 'A magic button that guarantees viral videos', at: 222.6, tone: 'bad'},
    right: {title: 'AI IS', text: 'A tool that helps you research, create better content, and improve faster', at: 228.0, tone: 'good'},
  },
  {
    kind: 'stack', from: 234.0, to: 239.0, cols: 3,
    items: [
      {at: 234.2, text: 'Start small', icon: 'zap'},
      {at: 235.8, text: 'Stay consistent', icon: 'repeat'},
      {at: 237.4, text: 'Help your audience', icon: 'target'},
    ],
  },
  {
    kind: 'hero', from: 239.0, to: 243.0,
    kicker: {text: 'IF YOU WANT TO GROW', at: 239.2},
    lines: [
      {text: 'YouTube channel', at: 240.2, size: 160, tone: 'accent'},
      {text: 'WITH PRACTICAL AI STRATEGIES', at: 241.0, size: 90},
    ],
  },
  {kind: 'cta', from: 243.0, to: 248.8},
  {
    kind: 'hero', from: 248.8, to: 252.5, icon: 'play',
    lines: [
      {text: 'SEE YOU IN THE', at: 249.0, size: 70, tone: 'muted'},
      {text: 'next video', at: 249.6, size: 170, tone: 'accent'},
      {text: 'Keep learning. Keep creating.', at: 250.2, size: 76},
    ],
  },
];

const renderScene = (def: SceneDef): React.ReactNode => {
  switch (def.kind) {
    case 'hero':
      return <HeroScene def={def} />;
    case 'stepIntro':
      return <StepIntroScene def={def} />;
    case 'stack':
      return <StackScene def={def} />;
    case 'versus':
      return <VersusScene def={def} />;
    case 'prompt':
      return <PromptScene def={def} />;
    case 'chart':
      return <ChartScene def={def} />;
    case 'cycle':
      return <CycleScene def={def} />;
    case 'equation':
      return <EquationScene def={def} />;
    case 'bigNumber':
      return <BigNumberScene def={def} />;
    case 'cta':
      return <CtaScene />;
  }
};

export const Scenes: React.FC = () => {
  return (
    <>
      {SCENE_DEFS.map((def, i) => (
        <SceneFrame key={i} from={def.from} to={def.to}>
          {renderScene(def)}
        </SceneFrame>
      ))}
    </>
  );
};
