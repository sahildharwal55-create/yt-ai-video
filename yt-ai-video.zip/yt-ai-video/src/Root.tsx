import React from 'react';
import {Composition} from 'remotion';
import {MainVideo} from './MainVideo';
import {DURATION_FRAMES, FPS} from './theme';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="YouTubeAI"
      component={MainVideo}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
};
