import React from 'react';
import {AbsoluteFill, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {useWindowedAudioData} from '@remotion/media-utils';
import {AccentContext, COLORS, useChapterAccent} from './theme';
import {getSpectrum} from './audioReactive';
import {Background} from './Background';
import {Waveform} from './Waveform';
import {Progress} from './Progress';
import {Captions} from './Captions';
import {Scenes} from './Scenes';

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const accent = useChapterAccent();

  const {audioData, dataOffsetInSeconds} = useWindowedAudioData({
    src: staticFile('audio.mp3'),
    frame,
    fps,
    windowInSeconds: 30,
  });
  const spectrum = getSpectrum(audioData, frame, fps, dataOffsetInSeconds);

  return (
    <AccentContext.Provider value={accent}>
      <AbsoluteFill name="Video" style={{backgroundColor: COLORS.bg}}>
        <Audio src={staticFile('audio.mp3')} />
        <Background spectrum={spectrum} />
        <Scenes />
        <Waveform spectrum={spectrum} />
        <Progress />
        <Captions />
      </AbsoluteFill>
    </AccentContext.Provider>
  );
};
