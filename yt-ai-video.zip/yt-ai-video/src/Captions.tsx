import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {
  AbsoluteFill,
  Easing,
  Interactive,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useDelayRender,
  useVideoConfig,
} from 'remotion';
import {createTikTokStyleCaptions} from '@remotion/captions';
import type {Caption, TikTokPage} from '@remotion/captions';
import {FONT} from './fonts';
import {useAccent} from './theme';

// Each phrase is its own page (pageBreakAfter in captions.json),
// this value only caps how many ms can be combined into one page.
const SWITCH_CAPTIONS_EVERY_MS = 2500;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const CaptionPage: React.FC<{page: TikTokPage}> = ({page}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const accent = useAccent();

  const nowMs = page.startMs + (frame / fps) * 1000;
  const enter = interpolate(frame, [0, 6], [0, 1], {
    ...clamp,
    easing: Easing.bezier(0.16, 1, 0.3, 1),
  });
  const exit = interpolate(frame, [durationInFrames - 4, durationInFrames], [1, 0], clamp);

  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 150}}>
      <Interactive.Div
        name="Caption"
        style={{
          opacity: enter * exit,
          translate: `0px ${(1 - enter) * 18}px`,
          scale: 0.94 + 0.06 * enter,
          display: 'flex',
          padding: '16px 46px 20px',
          borderRadius: 34,
          background: 'rgba(6,8,18,0.66)',
          border: '2px solid rgba(255,255,255,0.12)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.45)',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 78,
          letterSpacing: -1,
          color: '#fff',
          whiteSpace: 'pre',
        }}
      >
        {page.tokens.map((token, i) => {
          const active = nowMs >= token.fromMs && nowMs < token.toMs;
          // Words pop in as they are spoken; space is reserved so the pill never jumps
          const wordIn = interpolate(nowMs, [token.fromMs, token.fromMs + 120], [0, 1], clamp);
          return (
            <span
              key={`${token.fromMs}-${i}`}
              style={{
                display: 'inline-block',
                whiteSpace: 'pre',
                opacity: wordIn,
                translate: `0px ${(1 - wordIn) * 10}px`,
                scale: active ? 1.07 : 1,
                color: active ? accent : '#fff',
              }}
            >
              {i === 0 ? token.text.trimStart() : token.text}
            </span>
          );
        })}
      </Interactive.Div>
    </AbsoluteFill>
  );
};

export const Captions: React.FC = () => {
  const {fps} = useVideoConfig();
  const [captions, setCaptions] = useState<Caption[] | null>(null);
  const {delayRender, continueRender, cancelRender} = useDelayRender();
  const [handle] = useState(() => delayRender());

  const fetchCaptions = useCallback(async () => {
    try {
      const response = await fetch(staticFile('captions.json'));
      const data = await response.json();
      setCaptions(data);
      continueRender(handle);
    } catch (e) {
      cancelRender(e);
    }
  }, [continueRender, cancelRender, handle]);

  useEffect(() => {
    fetchCaptions();
  }, [fetchCaptions]);

  const pages = useMemo(() => {
    if (!captions) {
      return [] as TikTokPage[];
    }
    return createTikTokStyleCaptions({
      captions,
      combineTokensWithinMilliseconds: SWITCH_CAPTIONS_EVERY_MS,
    }).pages;
  }, [captions]);

  if (!captions) {
    return null;
  }

  return (
    <AbsoluteFill name="Captions">
      {pages.map((page, index) => {
        const next = pages[index + 1] ?? null;
        const lastToken = page.tokens[page.tokens.length - 1];
        const startFrame = Math.round((page.startMs / 1000) * fps);
        // Hide shortly after the last word, or when the next page starts
        const endMs = Math.min(next ? next.startMs : Infinity, lastToken.toMs + 350);
        const durationInFrames = Math.round((endMs / 1000) * fps) - startFrame;
        if (durationInFrames <= 0) {
          return null;
        }
        return (
          <Sequence key={index} from={startFrame} durationInFrames={durationInFrames}>
            <CaptionPage page={page} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
