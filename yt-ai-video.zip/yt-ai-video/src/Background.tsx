import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, tint, useAccent} from './theme';
import {average, boost} from './audioReactive';

export const Background: React.FC<{spectrum: number[]}> = ({spectrum}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const accent = useAccent();
  const t = frame / fps;
  const bass = boost(average(spectrum.slice(0, 5)));

  return (
    <AbsoluteFill name="Background" style={{backgroundColor: COLORS.bg, overflow: 'hidden'}}>
      {/* Accent glow, top-left, pulses with the voice */}
      <div
        style={{
          position: 'absolute',
          width: 1200,
          height: 1200,
          borderRadius: '50%',
          left: -80 + Math.sin(t * 0.35) * 180,
          top: -520 + Math.cos(t * 0.27) * 100,
          background: `radial-gradient(circle, ${tint(accent, 55)} 0%, transparent 65%)`,
          filter: 'blur(40px)',
          opacity: 0.5 + bass * 0.4,
          scale: 1 + bass * 0.08,
        }}
      />
      {/* Cool glow, bottom-right */}
      <div
        style={{
          position: 'absolute',
          width: 1100,
          height: 1100,
          borderRadius: '50%',
          right: -260 + Math.cos(t * 0.3) * 160,
          bottom: -620 + Math.sin(t * 0.22) * 90,
          background: 'radial-gradient(circle, rgba(59,130,246,0.40) 0%, transparent 65%)',
          filter: 'blur(40px)',
          opacity: 0.55 + bass * 0.25,
        }}
      />
      {/* Slowly drifting grid */}
      <div
        style={{
          position: 'absolute',
          inset: -80,
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
          translate: `${-((t * 14) % 80)}px ${-((t * 9) % 80)}px`,
          WebkitMaskImage: 'radial-gradient(ellipse at center, black 25%, transparent 75%)',
          maskImage: 'radial-gradient(ellipse at center, black 25%, transparent 75%)',
        }}
      />
      {/* Vignette */}
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.55) 100%)',
        }}
      />
    </AbsoluteFill>
  );
};
