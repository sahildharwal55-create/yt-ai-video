import React from 'react';
import {boost} from './audioReactive';
import {useAccent} from './theme';

// Mirrored equalizer along the bottom edge, driven by the voice
export const Waveform: React.FC<{spectrum: number[]}> = ({spectrum}) => {
  const accent = useAccent();
  const half = spectrum.slice(0, 24);
  const bars = [...half].reverse().concat(half);

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 28,
        height: 110,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        gap: 10,
        opacity: 0.55,
      }}
    >
      {bars.map((v, i) => (
        <div
          key={i}
          style={{
            width: 14,
            height: 8 + boost(v) * 100,
            borderRadius: 7,
            background: accent,
          }}
        />
      ))}
    </div>
  );
};
