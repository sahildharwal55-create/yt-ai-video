import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {CHAPTERS, COLORS} from './theme';
import {FONT} from './fonts';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Five step pills at the top, visible only during the five steps
export const Progress: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const steps = CHAPTERS.filter((c) => c.step);
  const current = steps.find((c) => t >= c.from && t < c.to);
  const visible = interpolate(t, [39.4, 40.2, 219.8, 220.6], [0, 1, 1, 0], clamp);

  return (
    <div
      style={{
        position: 'absolute',
        top: 52,
        left: 0,
        right: 0,
        display: 'flex',
        justifyContent: 'center',
        gap: 22,
        opacity: visible,
      }}
    >
      {steps.map((c) => {
        const p = interpolate(t, [c.from, c.to], [0, 1], clamp);
        const active = current?.id === c.id;
        return (
          <div
            key={c.id}
            style={{
              width: 220,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 10,
              opacity: active ? 1 : 0.55,
            }}
          >
            <div
              style={{
                width: '100%',
                height: 10,
                borderRadius: 10,
                background: 'rgba(255,255,255,0.14)',
                overflow: 'hidden',
              }}
            >
              <div
                style={{
                  width: `${p * 100}%`,
                  height: '100%',
                  background: c.color,
                  borderRadius: 10,
                }}
              />
            </div>
            <div
              style={{
                fontFamily: FONT,
                fontWeight: 700,
                fontSize: 22,
                letterSpacing: 3,
                color: active ? c.color : COLORS.muted,
              }}
            >
              {`${c.step}  ${c.label}`}
            </div>
          </div>
        );
      })}
    </div>
  );
};
