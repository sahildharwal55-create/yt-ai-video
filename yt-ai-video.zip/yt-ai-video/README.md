# YouTube x AI: motion graphics + captions

Remotion project (1920x1080, 30fps, 252.5s) built on your audio.

## Run (needs Node.js 18+)
    npm install
    npm run dev        # opens Remotion Studio (preview)
    npm run build      # renders out/youtube-ai.mp4

If `npm install` fails on version 4.0.528, run `npx create-video@latest`, copy this
project's `src/` and `public/` into it, then:
    npx remotion add @remotion/captions @remotion/media @remotion/media-utils @remotion/google-fonts

## Where to edit
- `public/captions.json`  caption words + timing (ms). Fix any wrong word here.
- `src/Scenes.tsx`        SCENE_DEFS = every scene, timed in seconds of the audio.
- `src/theme.ts`          chapter colors (CHAPTERS) and fps/duration.
- `src/Captions.tsx`      caption style (size, pill, highlight color).

## Note
Captions were read from the burned-in captions of your uploaded video (OCR + visual check),
so timing is approximate (about +/-0.2s). Check the Studio preview and adjust startMs/endMs if needed.
